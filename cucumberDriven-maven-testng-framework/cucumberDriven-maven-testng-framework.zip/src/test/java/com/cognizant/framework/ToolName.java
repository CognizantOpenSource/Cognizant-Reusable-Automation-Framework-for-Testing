package com.cognizant.framework;

public enum ToolName {

	/**
	 * Use Appium for execution
	 */
	APPIUM, REMOTEDRIVER;

}
